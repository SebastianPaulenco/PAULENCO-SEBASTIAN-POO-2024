﻿#include "pch.h"
#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Alpinist {  // Aici încep definirea clasei Alpinist

private: // Aici încep secțiunea in care declar atributele private ale clasei
    string nume; // Aici declar un atribut privat nume de tip string
    vector<int> aniExpediții; // Aici declar un atribut privat aniExpediții de tip vector
    string taraOrigine;  // Aici declar un atribut privat taraOrigine de tip string


public:  // Aici încep secțiunea cu metodele publice ale clasei

    Alpinist(string numeNou, vector<int> aniNou, string taraNou) {  // Aici încep definirea constructorului clasei
        nume = numeNou;  // Aici atribui parametrul numeNou atributului nume
        aniExpediții = aniNou;  // Aici atribui parametrul aniNou atributului aniExpediții
        taraOrigine = taraNou;  // Aici atribui parametrul taraNou atributului taraOrigine
    }

    ~Alpinist() {  // Aici încep definirea destructorului clasei
    }

    // Metoda pentru a afisa numele sportivului
    string getNume() { // Aici încep definirea metodei getNume
        return nume; // Aici returnez valoarea atributului nume
    }

    // Metoda pentru a afisa tara reprezentata de sportiv
    string getTaraOrigine() { // Aici încep definirea metodei getTaraOrigine
        return taraOrigine;  // Aici returnez valoarea atributului taraOrigine
    }

    // Metoda pentru a afisa anii expeditiilor
    void afiseazaAniiExpedițiilor() { // Aici încep definirea metodei afiseazaAniiExpedițiilor
        for (int an : aniExpediții) { // Aici încep o buclă care parcurge fiecare an din vectorul aniExpediții
            cout << an << " "; // Aici afișez anul curent urmat de un spațiu
        }
        cout << "\n";  // Aici trecem la o linie noua
    }

    // Metoda pentru a verifica dacă un alpinist a efectuat cel puțin două expediții într-o anumită perioadă
    bool aFacutMinimumDouaExpedițiiÎnPerioada(int anStart, int anSfârșit) {  // Aici încep definirea metodei aFacutMinimumDouaExpedițiiÎnPerioada
        int count = 0;  // Aici declar și inițializez o variabilă count cu 0
        for (int an : aniExpediții) {  // Aici încep o buclă care parcurge fiecare an din vectorul aniExpediții
            if (an >= anStart && an <= anSfârșit) { // Aici verific dacă anul curent este în intervalul [anStart, anSfârșit]
                count++; // Dacă anul curent este în intervalul [anStart, anSfârșit], incrementez count
            }
        }
        return count >= 2; // Aici returnez true dacă count este cel puțin 2 (adică dacă alpinistul a efectuat cel puțin două expediții în intervalul [anStart, anSfârșit])
    }
};

int main() {
    // Creăm un vector pentru a stoca toți alpiniștii
    vector<Alpinist> alpinisti; // Aici declar și inițializez un vector de obiecte Alpinist

    // Adăugăm alpiniștii în vector

    // Romania
    alpinisti.push_back(Alpinist("Constantin Lacatusu", { 2015, 2014 }, "Romania"));
    alpinisti.push_back(Alpinist("Sebastian Paulenco", { 2015, 2014 }, "Romania"));
    alpinisti.push_back(Alpinist("Cristian Gruia", { 2015, 2014 }, "Romania"));

    // Japonia
    alpinisti.push_back(Alpinist("Daijo Saito", { 2022, 2018 }, "Japonia"));
    alpinisti.push_back(Alpinist("Takanori Mashimo", { 2015, 2015 }, "Japonia"));
    alpinisti.push_back(Alpinist("Shinnosuke Ashikari", { 2015, 2015 }, "Japonia"));
    alpinisti.push_back(Alpinist("Kenta Kimura", { 2015, 2015 }, "Japonia"));
    alpinisti.push_back(Alpinist("Shun Kitsui", { 2015, 2015 }, "Japonia"));
    alpinisti.push_back(Alpinist("Kotaro Miyazu", { 2015, 2015 }, "Japonia"));
    alpinisti.push_back(Alpinist("Takehiro Nozawa", { 2015, 2015 }, "Japonia"));
    alpinisti.push_back(Alpinist("Seiya Nakasukasa", { 2010, 2009, 2009 }, "Japonia"));
    alpinisti.push_back(Alpinist("Yusuke Kuramoto", { 2009, 2009 }, "Japonia"));
    alpinisti.push_back(Alpinist("Yoshitaka Kameoka", { 2009, 2009 }, "Japonia"));
    alpinisti.push_back(Alpinist("Kohei Kotani", { 2009, 2009, 2007 }, "Japonia"));
    alpinisti.push_back(Alpinist("Daisuke Nakatsuka", { 2009, 2009 }, "Japonia"));
    alpinisti.push_back(Alpinist("Hiroki Yamamoto", { 2009, 2009, 2008 }, "Japonia"));
    alpinisti.push_back(Alpinist("Kenro Nakajima", { 2008, 2006 }, "Japonia"));
    alpinisti.push_back(Alpinist("Ken Kanazawa", { 1984, 1979 }, "Japonia"));

    // UK
    alpinisti.push_back(Alpinist("James Francis Crispin Fotheringham", { 2022, 2017 }, "UK"));
    alpinisti.push_back(Alpinist("Julian David Waren Freeman-Attwood", { 2022, 2017 }, "UK"));
    alpinisti.push_back(Alpinist("Nicholas Francis Colton", { 2022, 2017 }, "UK"));
    alpinisti.push_back(Alpinist("Paul Ramsden", { 2022, 2015, 2001 }, "UK"));
    alpinisti.push_back(Alpinist("Michael Alan Fowler", { 2015, 2011, 2001 }, "UK"));
    alpinisti.push_back(Alpinist("Graham Ivan Desroy", { 2012, 2011 }, "UK"));
    alpinisti.push_back(Alpinist("Alfred John Gregory", { 1955, 1955, 1955, 1955, 1955 }, "UK"));
    alpinisti.push_back(Alpinist("Peter Boultbee", { 1955, 1955, 1955, 1955, 1955 }, "UK"));
    alpinisti.push_back(Alpinist("Dennis P. Davis", { 1955, 1955, 1955, 1955 }, "UK"));
    alpinisti.push_back(Alpinist("Eric Earle Shipton", { 1952, 1952 }, "UK"));

    // USA
    alpinisti.push_back(Alpinist("Steven Mark Furman", { 2017, 2003 }, "USA"));
    alpinisti.push_back(Alpinist("Scott Robert Adamson", { 2014, 2013, 2013 }, "USA"));
    alpinisti.push_back(Alpinist("Christopher John Wright", { 2013, 2013, 2012 }, "USA"));
    alpinisti.push_back(Alpinist("David Alfred Gottlieb", { 2013, 2012, 2011, 2010, 2009, 2008 }, "USA"));
    alpinisti.push_back(Alpinist("Chad Lewis Kellog", { 2013, 2012, 2011 }, "USA"));
    alpinisti.push_back(Alpinist("Joseph N. Puryear", { 2010, 2009, 2008 }, "USA"));
    alpinisti.push_back(Alpinist("Peter David Ackroyd", { 2007, 2003, 2002 }, "USA"));
    alpinisti.push_back(Alpinist("C. James Frush", { 2007, 2003, 2002 }, "USA"));
    alpinisti.push_back(Alpinist("Daniel Taylor", { 1971, 1970 }, "USA"));

    // Germania
    alpinisti.push_back(Alpinist("Jost Kobusch", { 2021, 2019 }, "Germania"));
    alpinisti.push_back(Alpinist("Olaf Rainer Rieck", { 2008, 2002 }, "Germania"));
    alpinisti.push_back(Alpinist("Vera Morche", { 2008, 2002 }, "Germania"));
    alpinisti.push_back(Alpinist("Wolfgang Weinzierl", { 1972, 1972 }, "Germania"));
    alpinisti.push_back(Alpinist("Nikolaus Harder", { 1972, 1972 }, "Germania"));
    alpinisti.push_back(Alpinist("Peter Vogler", { 1972, 1972 }, "Germania"));
    alpinisti.push_back(Alpinist("Heinz Steinmetz", { 1955, 1955, 1955 }, "Germania"));
    alpinisti.push_back(Alpinist("Fritz Lobbicher", { 1955, 1955 }, "Germania"));
    alpinisti.push_back(Alpinist("Juergen Wellenkamp", { 1955, 1955, 1955 }, "Germania"));

    // Danemarca
    alpinisti.push_back(Alpinist("Henrik Jessen Hansen", { 2002, 2002 }, "Danemarca"));
    alpinisti.push_back(Alpinist("Allan Christensen", { 2002, 2002 }, "Danemarca"));
    alpinisti.push_back(Alpinist("Bo Belvedere Christensen", { 2002, 2002 }, "Danemarca"));
    alpinisti.push_back(Alpinist("Jan Mathorne", { 2002, 2002 }, "Danemarca"));


    // Georgia
    alpinisti.push_back(Alpinist("Archil Badriashvili", { 2019, 2019, 2017 }, "Georgia"));
    alpinisti.push_back(Alpinist("Bakari Gelashvili", { 2019, 2019, 2017 }, "Georgia"));
    alpinisti.push_back(Alpinist("Giorgi Tepnaze", { 2019, 2019, 2017 }, "Georgia"));

    // Iugoslavia
    alpinisti.push_back(Alpinist("Anton Karja", { 2007, 1991, 1979, 1974, 1974 }, "Iugoslavia"));
    alpinisti.push_back(Alpinist("Francek Knez", { 1984, 1979 }, "Iugoslavia"));

    // Franta
    alpinisti.push_back(Alpinist("Paul Marc Grobel", { 2008, 2008 }, "Franta"));

    // Tarile de Jos
    alpinisti.push_back(Alpinist("Adolf Alexander Verrijn Stuart", { 1982, 1972 }, "Tarile de Jos"));





    int numar = 1; // Aici am initializat o variabila numar cu 1. Aceasta variabila va fi folosita pentru a numerota alpinistii.
    for (Alpinist alpinist : alpinisti) { // Aici am inceput o bucla care parcurge fiecare alpinist din vectorul alpinisti.
        if (alpinist.aFacutMinimumDouaExpedițiiÎnPerioada(2014, 2023)) { // Aici apelez metoda aFacutMinimumDouaExpedițiiÎnPerioada pentru a verifica daca alpinistul curent a efectuat cel putin doua expeditii in perioada mentionata.
            cout << numar << ": Multiple tentative de premiera mondiala in Himalaya: " << alpinist.getNume() << ", Tara reprezentata de sportiv: " << alpinist.getTaraOrigine() << ", Anii expeditiilor: ";  // Daca alpinistul a efectuat cel putin doua expeditii in perioada mentionata, atunci afisez numarul alpinistului, numele alpinistului, tara de origine a alpinistului si textul "Anii expeditiilor: ".
            alpinist.afiseazaAniiExpedițiilor(); // Aici apelez metoda afiseazaAniiExpedițiilor pentru alpinistul curent pentru a afisa anii in care alpinistul a efectuat expeditii.
            numar++; // Aici incrementez numarul de ordine
        }
    }

    return 0;
}